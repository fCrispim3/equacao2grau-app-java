package br.com.equacao2grau;

public interface Interface {
	public double calcularDelta();
	public double calcularX1();
	public double calcularX2();


}
