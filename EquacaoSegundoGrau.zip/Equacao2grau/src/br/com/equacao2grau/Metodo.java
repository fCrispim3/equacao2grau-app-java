package br.com.equacao2grau;

public class Metodo implements Interface {

	private double a;
	private double b;
	private double c;
	
	
	public Metodo() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calcularDelta() {
		// TODO Auto-generated method stub
		return (this.b * this.b) - (4 * this.a * this.c);
	}

	@Override
	public double calcularX1() {
		// TODO Auto-generated method stub
		return (-this.b + Math.sqrt(calcularDelta())) / ( 2 * this.a);
	}

	@Override
	public double calcularX2() {
		// TODO Auto-generated method stub
		return (-this.b - Math.sqrt(calcularDelta())) / ( 2 * this.a);
	}

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	public double getC() {
		return c;
	}

	public void setC(double c) {
		this.c = c;
	}

}
