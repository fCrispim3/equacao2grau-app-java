package br.com.equacao2grau;

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		
		Metodo metodo = new Metodo();
		
		String a;
		String b;
		String c;
		
		Object [] opcao = {"Realizar Cálculos", "Encerrar o programa"};
		Object selecionarOpcao;
		
		JOptionPane.showMessageDialog(null, "Bem vindo ao calculador de raizes para equações do 2° grau: " + "\n                                        ax² + bx + c = 0", "Calculador de raízes", JOptionPane.PLAIN_MESSAGE);
		
		do {
			
		selecionarOpcao = JOptionPane.showInputDialog(null, "Escolha a opção", "Calculador de raízes", JOptionPane.QUESTION_MESSAGE, null, opcao, opcao[0]);
		
		if (selecionarOpcao == "Realizar Cálculos") {
			
		a = JOptionPane.showInputDialog(null, "Informe o valor de 'a'.", "Calculador de raízes", JOptionPane.QUESTION_MESSAGE);
			
		a = a.replace(",", ".");
		metodo.setA(Double.parseDouble(a));
		
		if ( metodo.getA() == 0) {
			JOptionPane.showMessageDialog(null, "a = 0, portanto não é uma equação do segundo grau.", "Calculador de raízes", JOptionPane.ERROR_MESSAGE);
			
		}
		
		else {
		
		b = JOptionPane.showInputDialog(null, "Informe o valor de 'b'.", "Calculador de raízes", JOptionPane.QUESTION_MESSAGE);
		c = JOptionPane.showInputDialog(null, "Informe o valor de 'c'.", "Calculador de raízes", JOptionPane.QUESTION_MESSAGE);
		
		b = b.replace(",", ".");
		c = c.replace(",", ".");
		metodo.setB(Double.parseDouble(b));
		metodo.setC(Double.parseDouble(c));
		
		if ( metodo.calcularDelta() < 0) {
			JOptionPane.showMessageDialog(null, "Δ = " + String.format("%.1f", metodo.calcularDelta()) + ". Negativo, não existem raízes reias.");
			
		}
		
		else if (metodo.calcularDelta() == 0) {
			JOptionPane.showMessageDialog(null, "Equação inserida: \n" + metodo.getA() + "x² " + metodo.getB()+"x " + metodo.getC() + "\n" + "Δ = " + String.format("%.1f", metodo.calcularDelta())  + " \nA equação possui uma raiz real: \n" + "x1 = " + String.format("%.2f", metodo.calcularX1()));	
			
		}
		
		else if (metodo.calcularDelta() > 0){
		JOptionPane.showMessageDialog(null, "Equação inserida: \n" +metodo.getA() + "x² " + metodo.getB()+"x " + metodo.getC()  +  "\n" + "Δ = " + String.format("%.1f", metodo.calcularDelta())  + "\nA equação possui duas raizes reais: \n" + "x1 = " + String.format("%.2f", metodo.calcularX1()) + " e x2 = " + String.format("%.2f", metodo.calcularX2()));
		
		}
		}
		}
		
		else {
			
			JOptionPane.showMessageDialog(null, " Programa criado por Felipe Crispim. \n                GitHub:    fCrispim3 ", "Calculador de raízes", JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
		}
		
		}while(selecionarOpcao != "Encerrar o programa");
	}

}
